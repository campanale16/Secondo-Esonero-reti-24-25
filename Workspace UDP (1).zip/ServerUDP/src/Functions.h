//General functions

void generate_numeric(char *password, int length) {
    for (int i = 0; i < length; i++) {
        password[i] = '0' + rand() % 10;
    }
    password[length] = '\0';
}

void generate_alpha(char *password, int length) {
    for (int i = 0; i < length; i++) {
        password[i] = 'a' + rand() % 26;
    }
    password[length] = '\0';
}

void generate_mixed(char *password, int length) {
    for (int i = 0; i < length; i++) {
        if (rand() % 2 == 0)
            password[i] = 'a' + rand() % 26;
        else
            password[i] = '0' + rand() % 10;
    }
    password[length] = '\0';
}

void generate_secure(char *password, int length) {
    const char *chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
    int char_count = strlen(chars);
    for (int i = 0; i < length; i++) {
        password[i] = chars[rand() % char_count];
    }
    password[length] = '\0';
}

void generate_unambiguous(char *password, int length) {
    const char *chars = "ACDEFGHJKLMNPQRTUVWXYabcdefghjkmnpqtuvwxy34679!@#$%^&*";
    int char_count = strlen(chars);
    for (int i = 0; i < length; i++) {
        password[i] = chars[rand() % char_count];
    }
    password[length] = '\0';
}
