// Socket creation and usage
#include "protocol.h"

int main() {

#if defined WIN32
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != NO_ERROR) {
        printf("Error at WSAStartup()\n");
        exit(EXIT_FAILURE);
    }
#endif

    int sock;
    struct sockaddr_in server, client;
    char input[BUFFERSZ];           // Buffer to receive input from client
    char password[33] = {0};        // Initialize password buffer to zero
    char type;                      // Type of password (e.g., 'n', 'a', 'm', 's', 'u')
    int length;                     // Length of the password
    int client_len = sizeof(client);

    srand(time(NULL)); // Initialize random number generator

    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("\nSocket creation failed...");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(PROTOPORT);

    // Bind socket to server address
    if (bind(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("\nBinding error...");
        close(sock);
        exit(EXIT_FAILURE);
    }

    printf("UDP Server listening on port %d\n", PROTOPORT);

    // Main loop to handle incoming requests
    while (1) {
        // Clear buffers before use
        memset(input, 0, sizeof(input));
        memset(password, 0, sizeof(password));

        // Receive message from client
        int recv_len = recvfrom(sock, input, BUFFERSZ - 1, 0, (struct sockaddr *)&client, &client_len);
        if (recv_len < 0) {
            perror("\nReceive error...");
            continue;
        }

        printf("New request from %s:%d\n", inet_ntoa(client.sin_addr), ntohs(client.sin_port));

        // Parse the request
        if (sscanf(input, " %c%d", &type, &length) != 2 || length < 6 || length > 32) {
            strcpy(password, "Invalid input or length");
        } else {
            // Handle the password request
            switch (type) {
                case 'n': generate_numeric(password, length); break;
                case 'a': generate_alpha(password, length); break;
                case 'm': generate_mixed(password, length); break;
                case 's': generate_secure(password, length); break;
                case 'u': generate_unambiguous(password, length); break;
                case 'q': //Do not send a response
                    printf("Quit command received. Skipping response.\n");
                    continue;
                default:
                    strcpy(password, "Invalid type");  //in the case the request does not follow the criteria
            }
        }

        // Send response back to client
        if (sendto(sock, password, strlen(password), 0, (struct sockaddr *)&client, client_len) < 0) {
            perror("\nSend error...");
        } else {
            printf("Sent password: %s\n\n", password);
        }
    }

    close(sock);
    return 0;
}
