// Client creation and usage

#include "protocol.h"

// Menu displayer
void display_help_menu() {
    printf("Password Generator Help Menu\n");
    printf("Commands:\n");
    printf("h [send]        : show this help menu\n");
    printf("n LENGTH [send] : generate numeric password (digits only)\n");
    printf("a LENGTH [send] : generate alphabetic password (lowercase letters)\n");
    printf("m LENGTH [send] : generate mixed password (lowercase letters and numbers)\n");
    printf("s LENGTH [send] : generate secure password (uppercase, lowercase, numbers, symbols)\n");
    printf("u LENGTH [send] : generate unambiguous secure password (no similar-looking characters)\n");
    printf("q [send]        : quit application\n");
    printf("LENGTH must be between 6 and 32 characters\n");
}

void main() {
#if defined WIN32
    WSADATA wsa_data;
    if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
        printf("WSAStartup failed.\n");
        exit(1);
    }
#endif

    int sock;
    struct sockaddr_in server;
    struct addrinfo hints, *res = NULL;
    char input[BUFFERSZ], response[BUFFERSZ];
    int server_len = sizeof(server);

    // Configure hints for getaddrinfo()
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;       // IPv4
    hints.ai_socktype = SOCK_DGRAM; // UDP socket

    // Resolve the server domain name
    if (getaddrinfo("passwdgen.uniba.it", NULL, &hints, &res) != 0) {
    	perror("Error: Could not resolve hostname.\n");
    }

    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PROTOPORT);
    memcpy(&server.sin_addr, &((struct sockaddr_in *)res->ai_addr)->sin_addr, sizeof(struct in_addr));

    // Creating the actual UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    printf("UDP Client started. Enter 'h' for help.\n");

    while (1) {
        printf("Enter command: ");
        fgets(input, BUFFERSZ, stdin);
        input[strcspn(input, "\n")] = '\0'; // Removes newline

        if (strcmp(input, "q") == 0) {
            printf("Quitting...\n");
            break;
        } else if (strcmp(input, "h") == 0) {
            display_help_menu();
            continue;
        }

        // Send input command to sever
        if (sendto(sock, input, strlen(input), 0, (struct sockaddr *)&server, server_len) < 0) {
            perror("\nSend failed");
            continue;
        }

        // Recieve the new password from server
        memset(response, 0, BUFFERSZ);
        int recv_len = recvfrom(sock, response, BUFFERSZ, 0, NULL, NULL);
        if (recv_len < 0) {
            perror("Receive failed");
        } else {
            response[recv_len] = '\0';
            printf("Server response: %s\n\n", response);
        }
    }

    close(sock);
#if defined WIN32
    WSACleanup();
#endif
}
